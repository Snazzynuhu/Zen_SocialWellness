import React from 'react'
import { Link } from 'react-router-dom';

import DashboardHeader from './admin/DashboardHeader'
import DashboardMenu from './admin/DashboardMenu'

const Header = () => {
    if (localStorage.getItem("tokenStore")) {
        return (
            <>
                <DashboardHeader />
                <DashboardMenu />
            </>
        )
    }
    else {
        return < GeneralHeader />
    }
}

const GeneralHeader = () => {

    return (
        <header className="header">
            <div id="rt-sticky-placeholder" style={{ height: '0px' }}></div>
            <div id="header-menu" className="header-menu menu-layout1">
                <div className="container-fluid">
                    <div className="row align-items-center">
                        <div className="col-lg-2">
                            <div className="temp-logo">
                                <Link to="/" className='logo_title' style={{ textShadow: "0px 5px 5px 1px grey", color: "red" }}><h3>Zen</h3>
                                </Link>
                            </div>
                        </div>
                        <div className="col-xl-6 col-lg-7 col-sm-7 col-8 d-flex justify-content-xl-start justify-content-center">
                            <div className="mobile-nav-item hide-on-desktop-menu">
                                <div className="mobile-toggler">
                                    <button type="button" className="mobile-menu-toggle">
                                        <i className="icofont-navigation-menu"></i>
                                    </button>
                                </div>
                            </div>
                            <nav id="dropdown" className="template-main-menu">
                                <button type="button" className="mobile-menu-toggle mobile-toggle-close">
                                    <i className="icofont-close"></i>
                                </button>
                                <ul className="menu-content">
                                    <li className="header-nav-item">
                                        <Link to="/" className="menu-link active">
                                            <a href="index.html" className="menu-link active">Home</a>
                                        </Link>
                                    </li>
                                    <li className="hide-on-mobile-menu">
                                        <a href="/#" className="menu-link have-sub">Community</a>
                                        <ul className="mega-menu mega-menu-col-2">
                                            <li>
                                                <ul className="sub-menu">
                                                    <li>
                                                        <a href="newsfeed.html">NewsFeed</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-timeline.html">Profile Timeline</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-about.html">Profile About</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-friends.html">Profile Friends</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-groups.html">Profile Group</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-photo.html">Profile Photo</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-video.html">Profile Video</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <ul className="sub-menu">
                                                    <li>
                                                        <a href="user-badges.html">Profile Badges</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums.html">Forums</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-forum.html">Forums Topic</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-timeline.html">Forums Timeline</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-info.html">Forums Info</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-members.html">Forums Members</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-media.html">Forums Media</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item hide-on-desktop-menu">
                                        <a href="/#" className="menu-link have-sub">Community</a>
                                        <ul className="sub-menu">
                                            <li>
                                                <a href="newsfeed.html">NewsFeed</a>
                                            </li>
                                            <li>
                                                <a href="user-timeline.html">Profile Timeline</a>
                                            </li>
                                            <li>
                                                <a href="user-about.html">Profile About</a>
                                            </li>
                                            <li>
                                                <a href="user-friends.html">Profile Friends</a>
                                            </li>
                                            <li>
                                                <a href="user-groups.html">Profile Group</a>
                                            </li>
                                            <li>
                                                <a href="user-photo.html">Profile Photo</a>
                                            </li>
                                            <li>
                                                <a href="user-video.html">Profile Video</a>
                                            </li>
                                            <li>
                                                <a href="user-badges.html">Profile Badges</a>
                                            </li>
                                            <li>
                                                <a href="forums.html">Forums</a>
                                            </li>
                                            <li>
                                                <a href="forums-forum.html">Forums Topic</a>
                                            </li>
                                            <li>
                                                <a href="forums-timeline.html">Forums Timeline</a>
                                            </li>
                                            <li>
                                                <a href="forums-info.html">Forums Info</a>
                                            </li>
                                            <li>
                                                <a href="forums-members.html">Forums Members</a>
                                            </li>
                                            <li>
                                                <a href="forums-media.html">Forums Media</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item">
                                        <a href="/#" className="menu-link have-sub">Blog</a>
                                        <ul className="sub-menu">
                                            <li>
                                                <a href="user-blog.html">Blog Grid</a>
                                            </li>
                                            <li>
                                                <a href="single-blog.html">Blog Details</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item">
                                        <a href="contact.html" className="menu-link">Contact Us</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div className="col-xl-4 col-lg-3 col-sm-5 col-4 d-flex justify-content-end">
                            <div className="header-action">
                                <ul>
                                    <li className="header-social">
                                        <a href="/#"><i className="icofont-facebook"></i></a>
                                        <a href="/#"><i className="icofont-twitter"></i></a>
                                        <a href="/#"><i className="icofont-linkedin"></i></a>
                                        <a href="/#"><i className="icofont-pinterest"></i></a>
                                        <a href="/#"><i className="icofont-skype"></i></a>
                                    </li>
                                    <li className="header-search-icon">
                                        <a href="#header-search" title="Search"><i className="icofont-search"></i></a>
                                    </li>
                                    <li className="login-btn">
                                        <Link to="/login" className="item-btn"><i className="fas fa-user">Login</i>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    )
}


const Sidebar = () => {
    return (
        <>
            <header className="fixed-header">
                <div className="header-menu">
                    <div className="navbar">
                        <div className="nav-item d-none d-sm-block">
                            <div className="header-logo">
                                <a href="index.html">
                                    <img src="media/logo.png" alt="Cirkle" />
                                </a>
                            </div>
                        </div>
                        <div className="nav-item nav-top-menu">
                            <nav id="dropdown" className="template-main-menu">
                                <ul className="menu-content">
                                    <li className="header-nav-item">
                                        <a href="index.html" className="menu-link active">
                                            Home
                                        </a>
                                    </li>
                                    <li className="header-nav-item">
                                        <a href="/#" className="menu-link have-sub">
                                            Community
                                        </a>
                                        <ul className="mega-menu mega-menu-col-2">
                                            <li>
                                                <ul className="sub-menu">
                                                    <li>
                                                        <a href="newsfeed.html">NewsFeed</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-timeline.html">Profile Timeline</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-about.html">Profile About</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-friends.html">Profile Friends</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-groups.html">Profile Group</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-photo.html">Profile Photo</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-video.html">Profile Video</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <ul className="sub-menu">
                                                    <li>
                                                        <a href="user-badges.html">Profile Badges</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums.html">Forums</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-forum.html">Forums Topic</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-timeline.html">Forums Timeline</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-info.html">Forums Info</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-members.html">Forums Members</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-media.html">Forums Media</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item">
                                        <a href="/#" className="menu-link have-sub">
                                            Pages
                                        </a>
                                        <ul className="sub-menu">
                                            <li>
                                                <a href="about-us.html">About</a>
                                            </li>
                                            <li>
                                                <a href="user-blog.html">Blog</a>
                                            </li>
                                            <li>
                                                <a href="shop.html">Shop</a>
                                            </li>
                                            <li>
                                                <a href="single-blog.html">Blog Details</a>
                                            </li>
                                            <li>
                                                <a href="single-shop.html">Shop Details</a>
                                            </li>
                                            <li>
                                                <a href="contact.html">Contact Us</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div>

                        <div className="nav-item header-control">
                            <div className="header-action">
                                <ul>
                                    <li className="header-nav-item">
                                        <a href="/profile" className="menu-link username">Username</a>
                                    </li>
                                    <li className="login-btn">
                                        <Link to="/logout" className="item-btn"><i className="fas fa-user">Logout</i>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* <div className="d-flex" id="wrapper">
   
    <div className="border-end bg-white" id="sidebar-wrapper">
      <div className="list-group list-group-flush">
        <a
          className="list-group-item list-group-item-action list-group-item-light p-3"
          href="#!"
        >
          Dashboard
        </a>
        <a
          className="list-group-item list-group-item-action list-group-item-light p-3"
          href="#!"
        >
          Shortcuts
        </a>
        <a
          className="list-group-item list-group-item-action list-group-item-light p-3"
          href="#!"
        >
          Overview
        </a>
        <a
          className="list-group-item list-group-item-action list-group-item-light p-3"
          href="#!"
        >
          Events
        </a>
        <a
          className="list-group-item list-group-item-action list-group-item-light p-3"
          href="#!"
        >
          Profile
        </a>
        <a
          className="list-group-item list-group-item-action list-group-item-light p-3"
          href="#!"
        >
          Status
        </a>
      </div>
    </div>
  </div> */}
        </>

    )
}
export default Header;



