import React from 'react'

function NewsFeed() {
    return (
        <div className="page-content">
            <div className="container">
                <div className="banner-user banner-forum">
                    <div className="banner-content">
                        <div className="media">
                            <div className="item-img">
                                <img src="media/figure/forum_7.jpg" alt="User" />
                            </div>
                            <div className="media-body">
                                <h3 className="item-title">Graphic Route</h3>
                                <div className="item-subtitle">@Graphic Route</div>
                                <ul className="item-social">
                                    <li><a href="#" className="bg-fb"><i className="icofont-facebook" /></a></li>
                                    <li><a href="#" className="bg-twitter"><i className="icofont-twitter" /></a></li>
                                    <li><a href="#" className="bg-dribble"><i className="icofont-dribbble" /></a></li>
                                    <li><a href="#" className="bg-youtube"><i className="icofont-brand-youtube" /></a></li>
                                    <li><a href="#" className="bg-behance"><i className="icofont-behance" /></a></li>
                                </ul>
                                <ul className="user-meta">
                                    <li>Group Type: <span>Public</span></li>
                                    <li>Posts: <span>30</span></li>
                                    <li>Members: <span>2,590</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="block-box user-top-header">
                    <ul className="menu-list">
                        <li className="active"><a href="#">Home</a></li>
                        <li><a href="#">Info</a></li>
                        <li><a href="#">Forum</a></li>
                        <li><a href="#">Members</a></li>
                        <li><a href="#">Media</a></li>
                    </ul>
                </div>
                <div className="row">
                    <div className="col-lg-8">
                        <div className="block-box post-input-tab forum-post-input">
                            <div className="media">
                                <div className="item-img">
                                    <img src="media/figure/chat_15.jpg" alt="img" />
                                </div>
                                <div className="media-body">
                                    <textarea name="status-input" id="status-input" className="form-control textarea" placeholder="Share what are you thinking here . . ." cols={30} rows={4} defaultValue={""} />
                                </div>
                            </div>
                            <div className="post-footer">
                                <div className="insert-btn">
                                    <a href="#"><i className="icofont-image" /></a>
                                    <a href="#"><i className="icofont-clip" /></a>
                                    <a href="#"><i className="icofont-tags" /></a>
                                    <a href="#"><i className="icofont-location-pin" /></a>
                                </div>
                                <div className="submit-btn">
                                    <a href="#">Post Comment</a>
                                </div>
                            </div>
                        </div>
                        <div className="block-box post-view">
                            <div className="post-header">
                                <div className="media">
                                    <div className="user-img">
                                        <img src="media/figure/chat_5.jpg" alt="Aahat" />
                                    </div>
                                    <div className="media-body">
                                        <div className="user-title"><a href="#">Michelle Jones</a> <i className="icofont-check" /></div>
                                        <ul className="entry-meta">
                                            <li className="meta-privacy"><i className="icofont-world" /> Public</li>
                                            <li className="meta-time">2 minutes ago</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="post-body">
                                <p>Dhaka is wonderful no matter what! <i className="icofont-wink-smile" /></p>
                                <div className="post-img">
                                    <img src="media/figure/post_12.jpg" alt="Post" />
                                </div>
                                <div className="post-meta-wrap">
                                    <div className="post-meta">
                                        <div className="post-reaction">
                                            <div className="reaction-icon">
                                                <img src="media/figure/reaction_1.png" alt="icon" />
                                                <img src="media/figure/reaction_2.png" alt="icon" />
                                                <img src="media/figure/reaction_3.png" alt="icon" />
                                            </div>
                                            <div className="meta-text">15</div>
                                        </div>
                                    </div>
                                    <div className="post-meta">
                                        <div className="meta-text">2 Comments</div>
                                        <div className="meta-text">05 Share</div>
                                    </div>
                                </div>
                            </div>
                            <div className="post-footer">
                                <ul>
                                    <li className="post-react">
                                        <a href="#"><i className="icofont-thumbs-up" />React!</a>
                                        <ul className="react-list">
                                            <li><a href="#"><img src="media/figure/reaction_1.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_4.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_7.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_6.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_5.png" alt="Like" /></a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#"><i className="icofont-comment" />Comment</a></li>
                                    <li className="post-share">
                                        <a href="javascript:void(0);" className="share-btn"><i className="icofont-share" />Share</a>
                                        <ul className="share-list">
                                            <li><a href="#" className="color-fb"><i className="icofont-facebook" /></a></li>
                                            <li><a href="#" className="color-messenger"><i className="icofont-facebook-messenger" /></a></li>
                                            <li><a href="#" className="color-instagram"><i className="icofont-instagram" /></a></li>
                                            <li><a href="#" className="color-whatsapp"><i className="icofont-brand-whatsapp" /></a></li>
                                            <li><a href="#" className="color-twitter"><i className="icofont-twitter" /></a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="block-box post-view">
                            <div className="post-header">
                                <div className="media">
                                    <div className="user-img">
                                        <img src="media/figure/chat_7.jpg" alt="Aahat" />
                                    </div>
                                    <div className="media-body">
                                        <div className="user-title"><a href="#">Fahim Rahman</a> <i className="icofont-check" /></div>
                                        <ul className="entry-meta">
                                            <li className="meta-privacy"><i className="icofont-world" /> Public</li>
                                            <li className="meta-time">8 minutes ago</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="post-body">
                                <div className="post-no-thumbnail">
                                    <p>I have great news to share with you all! I've been officially made a game streaming verified partner by Streamy http://radiustheme.com/ What does this mean? I'll be uploading new content every day, improving the quality and I'm gonna have access to games a month before the official release.</p>
                                    <p>This is a dream come true, thanks to all for the support!!!</p>
                                </div>
                                <div className="post-meta-wrap">
                                    <div className="post-meta">
                                        <div className="post-reaction">
                                            <div className="reaction-icon">
                                                <img src="media/figure/reaction_1.png" alt="icon" />
                                                <img src="media/figure/reaction_2.png" alt="icon" />
                                                <img src="media/figure/reaction_3.png" alt="icon" />
                                            </div>
                                            <div className="meta-text">15</div>
                                        </div>
                                    </div>
                                    <div className="post-meta">
                                        <div className="meta-text">2 Comments</div>
                                        <div className="meta-text">05 Share</div>
                                    </div>
                                </div>
                            </div>
                            <div className="post-footer">
                                <ul>
                                    <li className="post-react">
                                        <a href="#"><i className="icofont-thumbs-up" />React!</a>
                                        <ul className="react-list">
                                            <li><a href="#"><img src="media/figure/reaction_1.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_4.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_7.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_6.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_5.png" alt="Like" /></a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#"><i className="icofont-comment" />Comment</a></li>
                                    <li className="post-share">
                                        <a href="javascript:void(0);" className="share-btn"><i className="icofont-share" />Share</a>
                                        <ul className="share-list">
                                            <li><a href="#" className="color-fb"><i className="icofont-facebook" /></a></li>
                                            <li><a href="#" className="color-messenger"><i className="icofont-facebook-messenger" /></a></li>
                                            <li><a href="#" className="color-instagram"><i className="icofont-instagram" /></a></li>
                                            <li><a href="#" className="color-whatsapp"><i className="icofont-brand-whatsapp" /></a></li>
                                            <li><a href="#" className="color-twitter"><i className="icofont-twitter" /></a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="block-box post-view">
                            <div className="post-header">
                                <div className="media">
                                    <div className="user-img">
                                        <img src="media/figure/chat_13.jpg" alt="Aahat" />
                                    </div>
                                    <div className="media-body">
                                        <div className="user-title"><a href="#">Zinia Jisa</a> <i className="icofont-check" />joined the group <a href="#">Graphic Route</a> </div>
                                        <ul className="entry-meta">
                                            <li className="meta-privacy"><i className="icofont-world" /> Public</li>
                                            <li className="meta-time">8 minutes ago</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="post-body">
                                <div className="post-friends-view">
                                    <p>Dhaka is wonderful no matter what! <i className="icofont-wink-smile" /></p>
                                    <div className="profile-thumb">
                                        <div className="cover-img">
                                            <img src="media/figure/post_2.jpg" alt="cover-pic" />
                                        </div>
                                        <div className="media">
                                            <div className="profile-img">
                                                <a href="#"><img src="media/figure/author_3.jpg" alt="profile" /></a>
                                            </div>
                                            <div className="media-body">
                                                <div className="profile-name"><a href="#">Aahat Akter</a></div>
                                                <div className="user-name">@Aahat</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="block-box post-view">
                            <div className="post-header">
                                <div className="media">
                                    <div className="user-img">
                                        <img src="media/figure/chat_1.jpg" alt="Aahat" />
                                    </div>
                                    <div className="media-body">
                                        <div className="user-title"><a href="#">Julia Zessy</a> <i className="icofont-check" /> uploaded <a href="#">10 new photos</a> </div>
                                        <ul className="entry-meta">
                                            <li className="meta-privacy"><i className="icofont-world" /> Public</li>
                                            <li className="meta-time">10 minutes ago</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="post-body">
                                <p>Here are some of the photos from my last visit to Cox’s Bazar</p>
                                <ul className="post-img-list">
                                    <li><a href="#"><img src="media/figure/post_4.jpg" alt="Post" /></a></li>
                                    <li><a href="#"><img src="media/figure/post_5.jpg" alt="Post" /></a></li>
                                    <li><a href="#"><img src="media/figure/post_6.jpg" alt="Post" /></a></li>
                                    <li><a href="#"><img src="media/figure/post_7.jpg" alt="Post" /></a></li>
                                    <li><a href="#" data-photo={+5}><img src="media/figure/post_8.jpg" alt="Post" /></a></li>
                                </ul>
                                <div className="post-meta-wrap">
                                    <div className="post-meta">
                                        <div className="post-reaction">
                                            <div className="reaction-icon">
                                                <img src="media/figure/reaction_1.png" alt="icon" />
                                                <img src="media/figure/reaction_2.png" alt="icon" />
                                                <img src="media/figure/reaction_3.png" alt="icon" />
                                            </div>
                                            <div className="meta-text">15</div>
                                        </div>
                                    </div>
                                    <div className="post-meta">
                                        <div className="meta-text">2 Comments</div>
                                        <div className="meta-text">05 Share</div>
                                    </div>
                                </div>
                            </div>
                            <div className="post-footer">
                                <ul>
                                    <li className="post-react">
                                        <a href="#"><i className="icofont-thumbs-up" />React!</a>
                                        <ul className="react-list">
                                            <li><a href="#"><img src="media/figure/reaction_1.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_4.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_7.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_6.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_5.png" alt="Like" /></a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#"><i className="icofont-comment" />Comment</a></li>
                                    <li className="post-share">
                                        <a href="javascript:void(0);" className="share-btn"><i className="icofont-share" />Share</a>
                                        <ul className="share-list">
                                            <li><a href="#" className="color-fb"><i className="icofont-facebook" /></a></li>
                                            <li><a href="#" className="color-messenger"><i className="icofont-facebook-messenger" /></a></li>
                                            <li><a href="#" className="color-instagram"><i className="icofont-instagram" /></a></li>
                                            <li><a href="#" className="color-whatsapp"><i className="icofont-brand-whatsapp" /></a></li>
                                            <li><a href="#" className="color-twitter"><i className="icofont-twitter" /></a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="block-box post-view">
                            <div className="post-header">
                                <div className="media">
                                    <div className="user-img">
                                        <img src="media/figure/chat_8.jpg" alt="Aahat" />
                                    </div>
                                    <div className="media-body">
                                        <div className="user-title"><a href="#">Abul Hasan</a> <i className="icofont-check" /></div>
                                        <ul className="entry-meta">
                                            <li className="meta-privacy"><i className="icofont-world" /> Public</li>
                                            <li className="meta-time">8 minutes ago</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="post-body">
                                <div className="post-no-thumbnail">
                                    <p>I have great news to share with you all! I've been officially made a game streaming verified partner by Streamy http://radiustheme.com/ What does this mean? I'll be uploading new content every day, improving the quality and I'm gonna have access to games a month before the official release.</p>
                                    <p>This is a dream come true, thanks to all for the support!!!</p>
                                </div>
                                <div className="post-meta-wrap">
                                    <div className="post-meta">
                                        <div className="post-reaction">
                                            <div className="reaction-icon">
                                                <img src="media/figure/reaction_1.png" alt="icon" />
                                                <img src="media/figure/reaction_2.png" alt="icon" />
                                                <img src="media/figure/reaction_3.png" alt="icon" />
                                            </div>
                                            <div className="meta-text">15</div>
                                        </div>
                                    </div>
                                    <div className="post-meta">
                                        <div className="meta-text">2 Comments</div>
                                        <div className="meta-text">05 Share</div>
                                    </div>
                                </div>
                            </div>
                            <div className="post-footer">
                                <ul>
                                    <li className="post-react">
                                        <a href="#"><i className="icofont-thumbs-up" />React!</a>
                                        <ul className="react-list">
                                            <li><a href="#"><img src="media/figure/reaction_1.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_4.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_2.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_7.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_6.png" alt="Like" /></a></li>
                                            <li><a href="#"><img src="media/figure/reaction_5.png" alt="Like" /></a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#"><i className="icofont-comment" />Comment</a></li>
                                    <li className="post-share">
                                        <a href="javascript:void(0);" className="share-btn"><i className="icofont-share" />Share</a>
                                        <ul className="share-list">
                                            <li><a href="#" className="color-fb"><i className="icofont-facebook" /></a></li>
                                            <li><a href="#" className="color-messenger"><i className="icofont-facebook-messenger" /></a></li>
                                            <li><a href="#" className="color-instagram"><i className="icofont-instagram" /></a></li>
                                            <li><a href="#" className="color-whatsapp"><i className="icofont-brand-whatsapp" /></a></li>
                                            <li><a href="#" className="color-twitter"><i className="icofont-twitter" /></a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div className="post-comment">
                                <div className="comment-reply">
                                    <div className="user-img">
                                        <img src="media/figure/chat_15.jpg" alt="Aahat" />
                                    </div>
                                    <div className="input-box">
                                        <input type="text" name="comment" className="form-control" placeholder="Your Reply...." />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="block-box load-more-btn">
                            <a href="#" className="item-btn"><i className="icofont-refresh" />Load More Posts</a>
                        </div>
                    </div>
                    <div className="col-lg-4 widget-block widget-break-lg">
                        <div className="widget widget-memebers">
                            <div className="widget-heading">
                                <h3 className="widget-title">Group Administrators</h3>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="members-list">
                                <div className="media">
                                    <div className="item-img">
                                        <a href="#">
                                            <img src="media/figure/chat_1.jpg" alt="Chat" />
                                        </a>
                                    </div>
                                    <div className="media-body">
                                        <h4 className="item-title"><a href="#">Julia Zessy</a></h4>
                                        <div className="item-username">@zessy </div>
                                        <div className="member-status online"><i className="icofont-check" /></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="widget widget-memebers">
                            <div className="widget-heading">
                                <h3 className="widget-title">Members</h3>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <ul className="nav nav-tabs" role="tablist">
                                <li className="nav-item">
                                    <a className="nav-link active" data-toggle="tab" href="#newest-member" role="tab" aria-selected="true">NEWEST</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" data-toggle="tab" href="#popular-member" role="tab" aria-selected="false">POPULAR</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" data-toggle="tab" href="#active-member" role="tab" aria-selected="false">ACTIVE</a>
                                </li>
                            </ul>
                            <div className="tab-content">
                                <div className="tab-pane fade show active" id="newest-member" role="tabpanel">
                                    <div className="members-list">
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_1.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Aahat Akter</a></h4>
                                                <div className="item-username">@Aahat </div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_2.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Kazi Rahman</a></h4>
                                                <div className="item-username">@Rahman</div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_3.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Alia Karon</a></h4>
                                                <div className="item-username">@Alia</div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_4.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Masterero</a></h4>
                                                <div className="item-username">@Master</div>
                                                <div className="member-status offline"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="tab-pane fade" id="popular-member" role="tabpanel">
                                    <div className="members-list">
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_1.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Aahat Akter</a></h4>
                                                <div className="item-username">@Aahat </div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_2.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Kazi Rahman</a></h4>
                                                <div className="item-username">@Rahman</div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_3.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Alia Karon</a></h4>
                                                <div className="item-username">@Alia</div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_4.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Masterero</a></h4>
                                                <div className="item-username">@Master</div>
                                                <div className="member-status offline"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="tab-pane fade" id="active-member" role="tabpanel">
                                    <div className="members-list">
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_1.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Aahat Akter</a></h4>
                                                <div className="item-username">@Aahat </div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_2.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Kazi Rahman</a></h4>
                                                <div className="item-username">@Rahman</div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_3.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Alia Karon</a></h4>
                                                <div className="item-username">@Alia</div>
                                                <div className="member-status online"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                        <div className="media">
                                            <div className="item-img">
                                                <a href="#">
                                                    <img src="media/figure/chat_4.jpg" alt="Chat" />
                                                </a>
                                            </div>
                                            <div className="media-body">
                                                <h4 className="item-title"><a href="#">Masterero</a></h4>
                                                <div className="item-username">@Master</div>
                                                <div className="member-status offline"><i className="icofont-check" /></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="widget widget-groups">
                            <div className="widget-heading">
                                <h3 className="widget-title">My Groups</h3>
                                <div className="dropdown">
                                    <button className="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        ...
                                    </button>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a className="dropdown-item" href="#">Close</a>
                                        <a className="dropdown-item" href="#">Edit</a>
                                        <a className="dropdown-item" href="#">Delete</a>
                                    </div>
                                </div>
                            </div>
                            <div className="group-list">
                                <div className="media">
                                    <div className="item-img">
                                        <a href="#">
                                            <img src="media/groups/groups_9.jpg" alt="group" />
                                        </a>
                                    </div>
                                    <div className="media-body">
                                        <h4 className="item-title"><a href="#">Kito Development</a></h4>
                                        <div className="item-member">265 Members</div>
                                    </div>
                                </div>
                                <div className="media">
                                    <div className="item-img">
                                        <a href="#">
                                            <img src="media/groups/groups_10.jpg" alt="group" />
                                        </a>
                                    </div>
                                    <div className="media-body">
                                        <h4 className="item-title"><a href="#">Chef Express</a></h4>
                                        <div className="item-member">4,265 Members</div>
                                    </div>
                                </div>
                                <div className="media">
                                    <div className="item-img">
                                        <a href="#">
                                            <img src="media/groups/groups_11.jpg" alt="group" />
                                        </a>
                                    </div>
                                    <div className="media-body">
                                        <h4 className="item-title"><a href="#">Photo Contest</a></h4>
                                        <div className="item-member">1,265 Members</div>
                                    </div>
                                </div>
                                <div className="media">
                                    <div className="item-img">
                                        <a href="#">
                                            <img src="media/groups/groups_12.jpg" alt="group" />
                                        </a>
                                    </div>
                                    <div className="media-body">
                                        <h4 className="item-title"><a href="#">WP Developers</a></h4>
                                        <div className="item-member">265 Members</div>
                                    </div>
                                </div>
                            </div>
                            <div className="see-all-btn">
                                <a href="#" className="item-btn">See All Groups</a>
                            </div>
                        </div>
                        <div className="widget widget-banner">
                            <h3 className="item-title">Most Popular</h3>
                            <div className="item-subtitle">Circle Application</div>
                            <a href="#" className="item-btn">
                                <span className="btn-text">Register Now</span>
                                <span className="btn-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width="21px" height="10px">
                                        <path fillRule="evenodd" d="M16.671,9.998 L12.997,9.998 L16.462,6.000 L5.000,6.000 L5.000,4.000 L16.462,4.000 L12.997,0.002 L16.671,0.002 L21.003,5.000 L16.671,9.998 ZM17.000,5.379 L17.328,5.000 L17.000,4.621 L17.000,5.379 ZM-0.000,4.000 L3.000,4.000 L3.000,6.000 L-0.000,6.000 L-0.000,4.000 Z" />
                                    </svg>
                                </span>
                            </a>
                            <div className="item-img">
                                <img src="media/figure/widget_banner_1.png" alt="banner" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default NewsFeed