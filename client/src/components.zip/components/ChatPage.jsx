import React from 'react';
import './ChatPage.css';
import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import axios from 'axios';




const ChatPage = ({ socket }) => {

    // const message = {
    //     id: "",
    //     user: { id: "", name: "" },
    //     value: "",
    //     time: ""
    // };


    // const [messages, setMessages] = useState();
    const [contactsRead, setContactsRead] = useState([])
    const [contacts, setContacts] = useState([]);
    const [message, setMessage] = useState("");
    const [recipient, setRecipient] = useState("");
    const [value, setValue] = useState({});
    const [chats, setChats] = useState([]);
    const [preview, setPreview] = useState("");
    const [contactActive, setContactActive] = useState([]);



    // const handleSubmit = (e) => {
    //     e.preventDefault();

    //     const input = document.getElementById('input');

    //     if (input.value) {
    //         const message = {
    //             id: localStorage.getItem("user"),
    //             user: defaultUser,
    //             value: input.value,
    //             time: Date.now()
    //         };

    //         socket.emit('chat message', message);
    //     }
    // };

    const handleSearch = (e) => {

        let query = e.target.value;
        console.log(query);
        console.log({ contactsRead: contactsRead });
        if (query.trim() === "") {
            setContacts(contactsRead)
        } else {
            const result = contactsRead.filter((contact) => {
                if (contact.firstname.toLowerCase().indexOf(query.toLowerCase().trim()) > -1) {
                    return true
                }
            });

            const recentChats = new Set();
            let prevId = null;
            result.forEach((chat) => {

                if (chat.id !== prevId) {
                    recentChats.add(chat)
                }
                prevId = chat.id;
            })
            // console.log(result)
            setContacts(Array.from(recentChats));
        }
    }
    const loadChats = async () => {
        try {
            const res = await axios.post("http://localhost:3000/chats/all", {
                sender_id: localStorage.getItem("user"),
                recipient_id: recipient
            });
            setChats(res.data.chats)

        } catch (err) {
            throw err
        }
    }


    useEffect(() => {

        // socket.on('chat message', async (message) => {

        //     const input = document.getElementById('input');
        //     const messageDOM = document.getElementById('messages');
        //     const item = document.createElement('li');
        //     message = "Hi Nuhu";
        //     messageDOM.appendChild(item);
        //     window.scrollTo(0, document.body.scrollHeight);
        //     try {
        //         const res = await axios.post("http://localhost:3000/chats/create", {
        //             sender_id: localStorage.getItem("user"),
        //             recipient_id: "761579f7-1cd0-430d-a99b-4c5c7bddc733",
        //             content: message
        //         });
        //         console.log(message);
        //     } catch (err) {
        //         throw err
        //     }
        // });

        const messageListener = (message) => {
            // console.log(message)
            // setMessages((prevMessages) => {
            //     const newMessages = { ...prevMessages };
            //     newMessages[message.id] = message;
            //     return newMessages;
            // });
        };



        const deleteMessageListener = (messageID) => {
            // console.log("deletemessagelistener:" + messageID)
            // setMessages((prevMessages) => {
            //     const newMessages = { ...prevMessages };
            //     delete newMessages[messageID];
            //     return newMessages;
            // });
        };

        handleAllContactsLoad()


        // socket.on('message', (message) => {
        //     console.log("Received:" + message)
        // });
        // return () => {
        //     socket.off('message');
        // }


    }, []);

    useEffect(() => {
        socket.on('response', loadChats);
        console.log("responsed");

        socket.on('message', loadChats);
        console.log("messaged");

        return () => {
            socket.off('response');
            socket.off('message');
        };
    }, []);

    const insertChatMessage = async () => {
        console.log("recipient" + recipient);
        const userId = localStorage.getItem("user")
        if (recipient && (recipient !== userId)) {
            try {
                const res = await axios.post("http://localhost:3000/chats/create", {
                    sender_id: userId,
                    recipient_id: recipient,
                    content: message
                });
                console.log(message);
            } catch (err) {
                throw err
            }
        }

    }

    const handleContactsLoad = async () => {


        try {
            const res = await axios.post("http://localhost:3000/chats/some", {
                user_id: localStorage.getItem("user")
            });
            // const currentIndex = e.currentTarget.getAttribute("data-index");
            const recentChats = new Set();
            let prevId = null;
            res.data.chats.forEach((chat) => {

                if (chat.id !== prevId) {
                    recentChats.add(chat)
                }
                prevId = chat.id;
            })
            // setContacts(res.data.chats)
            // console.log(res.data.chats)
            console.log(Array.from(recentChats))
            setContacts(Array.from(recentChats))
        } catch (err) {
            throw err
        }

    }

    const handleAllContactsLoad = async () => {


        try {
            const res = await axios.get("http://localhost:3000/chats/users");
            console.log({ chats: res.data.chats })

            const recentChats = new Set();
            let prevId = null;

            res.data.chats.reverse().forEach((chat) => {

                if (chat.id !== prevId) {
                    recentChats.add(chat)
                }
                prevId = chat.id;
            })
            console.log({ recent: Array.from(recentChats) })

            setContacts(Array.from(recentChats))

            setContactsRead(Array.from(recentChats))

        } catch (err) {
            throw err
        }

    }

    const handleChatsLoad = async (e) => {

        const recipientId = e.currentTarget.getAttribute("data-id");

        const contactTabs = document.querySelectorAll('.contact');

        contactTabs.forEach(tab => {
            tab.classList.remove("active");
        });

        e.currentTarget.classList.add("active");
        setRecipient(recipientId)


        console.log("sender:" + localStorage.getItem("user"), "reipient" + recipientId);


        try {
            const res = await axios.post("http://localhost:3000/chats/all", {
                sender_id: localStorage.getItem("user"),
                recipient_id: recipientId
            });
            setChats(res.data.chats)

        } catch (err) {
            throw err
        }

    }

    const handleChange = (e) => {

        setMessage(e.target.value)
        console.log("messageState:" + e.target.value)
    }


    const submitForm = (e) => {
        e.preventDefault();
        insertChatMessage()
        socket.emit('message', 'my socket message');
        loadChats()

        // socket.emit('response');
    };

    return (
        <div id="frame">
            <div id="sidepanel">

                <div id="profile">
                    <div className="wrap">
                        <img id="profile-img" src={localStorage.getItem("userAvatar")} className="online" alt />
                        <p>{localStorage.getItem("userName")}</p>
                        <i className="fa fa-chevron-down expand-button" aria-hidden="true" />
                        <div id="status-options">
                            <ul>
                                <li id="status-online" className="active"><span className="status-circle" /> <p>Online</p></li>
                                <li id="status-away"><span className="status-circle" /> <p>Away</p></li>
                                <li id="status-busy"><span className="status-circle" /> <p>Busy</p></li>
                                <li id="status-offline"><span className="status-circle" /> <p>Offline</p></li>
                            </ul>
                        </div>
                        <div id="expanded">
                            <label htmlFor="twitter"><i className="fa fa-facebook fa-fw" aria-hidden="true" /></label>
                            <input name="twitter" type="text" defaultValue="mikeross" />
                            <label htmlFor="twitter"><i className="fa fa-twitter fa-fw" aria-hidden="true" /></label>

                            <input name="twitter" type="text" defaultValue="ross81" />
                            <label htmlFor="twitter"><i className="fa fa-instagram fa-fw" aria-hidden="true" /></label>
                            <input name="twitter" type="text" defaultValue="mike.ross" />
                        </div>
                    </div>
                </div>

                <div id="search">
                    <label htmlFor><i className="fa fa-search" aria-hidden="true" /></label>
                    <input onChange={handleSearch} type="text" placeholder="Search contacts..." />
                </div>
                <div id="contacts">
                    <ul>
                        {
                            
                            contacts.map((contact, index) => {
                                return (contact.id !== localStorage.getItem("user") ?

                                    <li key={index} data-id={contact.id} onClick={handleChatsLoad} className="contact">
                                        <div className="wrap">
                                            <span className="contact-status online" />
                                            <img src={contact.avatar} alt />

                                            <div className="meta">
                                                <p className="name">{contact.firstname + " " + contact.lastname}</p>
                                                <p className="preview">{contact.content}</p>
                                            </div>
                                        </div>
                                    </li>

                                    : null

                                )

                                // return (
                                //     <li key={index} className="contact" data-id={contact.sender_id} data-index={index} onClick={handleChatsLoad}>
                                //         <div className="wrap" >
                                //             <span className="contact-status online" />
                                //             <img src={contact.avatar} alt="avatar" />

                                //             <div className="meta">
                                //                 <p className="name">{contact.firstname + " " + contact.lastname}</p>
                                //                 <p className="preview">{contact.content}</p>
                                //             </div>
                                //         </div>
                                //     </li>

                                // )
                            })

                        }

                    </ul>
                </div>
            </div>
            <div className="content">

                <div id="messages" className="messages">

                    <ul>
                        {
                            chats.map((chat, index) => {
                                return (
                                    (chat.recipient_id === localStorage.getItem("user"))
                                        ?
                                        <li key={index} className="sent">
                                            <img src={chat.avatar} alt="avatar" />
                                            <p>{chat.content}</p>
                                        </li>
                                        :
                                        <li key={index} className="replies">
                                            <img src={chat.avatar} alt="avatar" />
                                            <p>{chat.content}</p>
                                        </li>
                                )
                            })
                        }


                    </ul>

                </div>

                <div className="message-input">
                    <div className="wrap">
                        {/* <input type="text" placeholder="Write your message..." />
                        <button className="submit"><i className="fa fa-paper-plane" aria-hidden="true" /></button> */}

                        <form onSubmit={submitForm}>
                            <input
                                type="text"
                                id="input"
                                defaultValue={value.value}
                                autoFocus
                                placeholder="Write your message..."
                                onChange={handleChange}
                            />
                            <button className="submit"><i className="fa fa-paper-plane" aria-hidden="true" /></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>



    )
}


export default ChatPage






























































































