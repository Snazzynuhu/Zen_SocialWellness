import React from 'react'
import { Link } from 'react-router-dom';

const HeaderUser = () => {

    return (
        <header className="header header-user">
            <div id="rt-sticky-placeholder" style={{ height: '0px' }}></div>
            <div id="header-menu" className="header-menu menu-layout1">
                <div className="container-fluid">
                    <div className="row align-items-center">
                        <div className="col-lg-2">
                            <div className="temp-logo">
                                <Link to="/" className='logo_title' style={{ textShadow: "0px 5px 5px 1px grey", color: "red" }}><h3>Zen</h3>
                                </Link>
                            </div>
                        </div>
                        <div className="col-xl-6 col-lg-7 col-sm-7 col-8 d-flex justify-content-xl-start justify-content-center">
                            <div className="mobile-nav-item hide-on-desktop-menu">
                                <div className="mobile-toggler">
                                    <button type="button" className="mobile-menu-toggle">
                                        <i className="icofont-navigation-menu"></i>
                                    </button>
                                </div>
                            </div>
                            <nav id="dropdown" className="template-main-menu">
                                <button type="button" className="mobile-menu-toggle mobile-toggle-close">
                                    <i className="icofont-close"></i>
                                </button>
                                <ul className="menu-content">
                                    <li className="header-nav-item">
                                        <Link to="/" className="menu-link active">
                                            <a href="index.html" className="menu-link active">Home</a>
                                        </Link>
                                    </li>
                                    <li className="hide-on-mobile-menu">
                                        <a href="/#" className="menu-link have-sub">Community</a>
                                        <ul className="mega-menu mega-menu-col-2">
                                            <li>
                                                <ul className="sub-menu">
                                                    <li>
                                                        <a href="newsfeed.html">NewsFeed</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-timeline.html">Profile Timeline</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-about.html">Profile About</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-friends.html">Profile Friends</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-groups.html">Profile Group</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-photo.html">Profile Photo</a>
                                                    </li>
                                                    <li>
                                                        <a href="user-video.html">Profile Video</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <ul className="sub-menu">
                                                    <li>
                                                        <a href="user-badges.html">Profile Badges</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums.html">Forums</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-forum.html">Forums Topic</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-timeline.html">Forums Timeline</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-info.html">Forums Info</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-members.html">Forums Members</a>
                                                    </li>
                                                    <li>
                                                        <a href="forums-media.html">Forums Media</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item hide-on-desktop-menu">
                                        <a href="/#" className="menu-link have-sub">Community</a>
                                        <ul className="sub-menu">
                                            <li>
                                                <a href="newsfeed.html">NewsFeed</a>
                                            </li>
                                            <li>
                                                <a href="user-timeline.html">Profile Timeline</a>
                                            </li>
                                            <li>
                                                <a href="user-about.html">Profile About</a>
                                            </li>
                                            <li>
                                                <a href="user-friends.html">Profile Friends</a>
                                            </li>
                                            <li>
                                                <a href="user-groups.html">Profile Group</a>
                                            </li>
                                            <li>
                                                <a href="user-photo.html">Profile Photo</a>
                                            </li>
                                            <li>
                                                <a href="user-video.html">Profile Video</a>
                                            </li>
                                            <li>
                                                <a href="user-badges.html">Profile Badges</a>
                                            </li>
                                            <li>
                                                <a href="forums.html">Forums</a>
                                            </li>
                                            <li>
                                                <a href="forums-forum.html">Forums Topic</a>
                                            </li>
                                            <li>
                                                <a href="forums-timeline.html">Forums Timeline</a>
                                            </li>
                                            <li>
                                                <a href="forums-info.html">Forums Info</a>
                                            </li>
                                            <li>
                                                <a href="forums-members.html">Forums Members</a>
                                            </li>
                                            <li>
                                                <a href="forums-media.html">Forums Media</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item">
                                        <a href="/#" className="menu-link have-sub">Blog</a>
                                        <ul className="sub-menu">
                                            <li>
                                                <a href="user-blog.html">Blog Grid</a>
                                            </li>
                                            <li>
                                                <a href="single-blog.html">Blog Details</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li className="header-nav-item">
                                        <a href="contact.html" className="menu-link">Contact Us</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div className="col-xl-4 col-lg-3 col-sm-5 col-4 d-flex justify-content-end">
                            <div className="header-action">
                                <ul>
                                    <li className="header-social">
                                        <a href="/#"><i className="icofont-facebook"></i></a>
                                        <a href="/#"><i className="icofont-twitter"></i></a>
                                        <a href="/#"><i className="icofont-linkedin"></i></a>
                                        <a href="/#"><i className="icofont-pinterest"></i></a>
                                        <a href="/#"><i className="icofont-skype"></i></a>
                                    </li>
                                    <li className="header-search-icon">
                                        <a href="#header-search" title="Search"><i className="icofont-search"></i></a>
                                    </li>
                                    <li className="login-btn">
                                        <Link to="/login" className="item-btn"><i className="fas fa-user">Login</i>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    )
}

export default HeaderUser