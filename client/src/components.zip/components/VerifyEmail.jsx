import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios'

function VerifyEmail() {
    const nav = useNavigate();
    const { token } = useParams();

    const [verifiedUser, setVerifiedUser] = useState(false);

    const verify = async () => {
        try {
            const res = await axios.get(`http://localhost:3000/users/verify/${token}`);

            if (res.data.status === 1) {
                setVerifiedUser(true)
                nav("/verified")
            } else {
                setVerifiedUser(false)
                nav("/verifyfail")
            }
        } catch (err) {
            throw err
        }
    }

    useEffect(() => {
        verify()
    }, [])


    return

}

export default VerifyEmail
