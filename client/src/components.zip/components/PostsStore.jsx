import axios from "axios"
import React from "react"
import { useEffect, useState } from "react"
import './PostStore.css'
import { useNavigate } from "react-router-dom"
import moment from 'moment'
import DataTable from 'react-data-table-component'





const Table = () => {
    const nav = useNavigate()


    const handleDelete = async (e) => {
        e.preventDefault();
        try {
            const res = await axios.post(`http://localhost:3000/notes/delete`, {
                id: e.target.getAttribute("data-id")
            });

            if (res.data.deleted > 0) {
                fetchPosts()
                setPosts([...posts])
                console.log(res.data.msg);
            }

        } catch (err) {
            console.error(err);
        }
    };


    const Button = () => {
        return <div className="remove" onClick={handleDelete}>
            <button >Delete</button>
        </div>
    }

    const columns = [
        {
            name: 'Author',
            selector: row => row.author_name,
        },
        {
            name: 'Title',
            selector: row => row.content,
        },

        {
            name: 'Content',
            selector: row => row.content,
        },
        {
            name: 'Date',
            selector: row => moment(row.createdAt).calendar(),
        },
        {
            name: 'Action',
            Button: true,
            selector: row => row.id,
            cell: (row) => (
                <button onClick={handleDelete} data-id={row.id} class="btn btn-danger">Delete</button>
            )
        },
    ];



    const [posts, setPosts] = useState([])

    const fetchPosts = async () => {
        const res = await axios.post("http://www.localhost:3000/notes/all")

        console.log(res.data.notes);

        if (res) {
            localStorage.setItem("noteId", res.data.notes.id);
            const posts = res.data.notes

            console.log("outcome:", res.data.notes);
            const notes = res.data.notes;
            const ids = notes.forEach(note => {
                return note.id
            })
            console.log("my notes", ids);
            setPosts(posts)
        }
    }



    useEffect(() => {
        fetchPosts()
    }, [])

    return (

        <DataTable
            columns={columns}
            data={posts}
        />

    );
};

export default Table